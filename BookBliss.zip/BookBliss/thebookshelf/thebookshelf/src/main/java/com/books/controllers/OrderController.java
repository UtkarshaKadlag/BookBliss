package com.books.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.books.entities.Order;
import com.books.services.OrderServices;

@RestController
@RequestMapping("/order")
public class OrderController {
	
	@Autowired
	private OrderServices orderservices;
	
	@GetMapping
	public ResponseEntity<?> getAll()
	{
		List<Order> orders = orderservices.getOrderDetails();
		return ResponseEntity.ok(orders);
	}
	
	@PostMapping
	public ResponseEntity<?> addOrderDetails(@RequestBody Order order)
	{
		try 
		{
			Order orders = orderservices.addOrderDetails(order);
			return new ResponseEntity<>(orders, HttpStatus.CREATED);
		}
		catch(Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}
	
	@PutMapping("/order/{id}")
	public ResponseEntity<?> updateBook(@PathVariable long id,@RequestBody Order orders){
		try 
		{
			orderservices.updateOrderD(id, orders);
			return new ResponseEntity<>(HttpStatus.OK);
		}
		catch(Exception e) 
		{
			return new ResponseEntity<>("An unexpected error occurred..",HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}

