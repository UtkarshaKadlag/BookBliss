package com.books.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.books.entities.Payment;
import com.books.services.PaymentServices;

@RestController
@RequestMapping("/payment")
public class PaymentController {
	
	@Autowired
	private PaymentServices paymentServices;
	
	@PostMapping
	public ResponseEntity<?> addPayment(@RequestBody Payment payment)
	{
		try 
		{
			Payment pay = paymentServices.addPayment(payment);
			return new ResponseEntity<>(payment, HttpStatus.CREATED);
		}
		catch(Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}
	
}
