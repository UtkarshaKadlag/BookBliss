package com.books.dto;

public class ErrorDto {
	public String error;

	

	public ErrorDto(String error) {
		super();
		this.error = error;
	}



	public String getError() {
		return error;
	}



	public void setError(String error) {
		this.error = error;
	}
	
}
