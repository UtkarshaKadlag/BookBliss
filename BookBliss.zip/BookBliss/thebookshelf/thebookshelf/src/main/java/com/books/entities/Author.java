package com.books.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;

import org.springframework.data.annotation.Id;

@Entity
@Table(name="author")
public class Author 
{
	@javax.persistence.Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long author_ID;
		@Column(name="aname",length=20)
		private String aname;
		@Column(name="description",length=100)
		private String description;
		
		
		public Author() {
			super();
		}
		public Author(long author_ID,String aname, String description) {
			super();
			this.author_ID=author_ID;
			this.aname = aname;
			this.description = description;
		}
		
		
		public long getAuthor_ID() {
			return author_ID;
		}
		public void setAuthor_ID(long author_ID) {
			this.author_ID = author_ID;
		}
		public String getAname() {
			return aname;
		}
		public void setAname(String aname) {
			this.aname = aname;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		@Override
		public String toString() {
			return "Author [ auhtor_ID=" +author_ID+"aname=" + aname + ", description=" + description + "]";
		}
		
		
}
