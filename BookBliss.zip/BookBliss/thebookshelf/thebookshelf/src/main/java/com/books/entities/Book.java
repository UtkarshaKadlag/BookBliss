package com.books.entities;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="books")
public class Book 
{
	@javax.persistence.Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long book_ID;
	@Column(length = 100, name = "book_name")
	private String bookName;
	@Column(name = "price")
	private float price;
	@Column(name = "quantity")
	private int quantity;
	@Column(name = "description")
	private String description;
	@ManyToOne(cascade =CascadeType.PERSIST,fetch = FetchType.EAGER)
	@JoinColumn(name = "author_id")
	private Author author;
	 @ManyToOne(fetch = FetchType.LAZY)
	 @JoinColumn(name = "order_ID", nullable = false)
	 private Order order;
	@Column(name="category")
	private Category category;
	public Book() 
	{
		super();
	}
	
	public Book(long book_ID,String bookName, float price, int quantity, String description, Author author,Category category) 
	{
		super();
		this.book_ID=book_ID;
		this.bookName = bookName;
		this.price = price;
		this.quantity = quantity;
		this.description = description;
		this.author = author;
		this.category=category;
	}
	
	
	
	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public long getBook_ID() {
		return book_ID;
	}

	public void setBook_ID(long book_ID) {
		this.book_ID = book_ID;
	}

	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Author getAuthor() {
		return author;
	}
	public void setAuthor(Author author) {
		this.author = author;
	}

	@Override
	public String toString() {
		return "Book [book_ID=" + book_ID + ", bookName=" + bookName + ", price=" + price + ", quantity=" + quantity
				+ ", description=" + description + ", author=" + author +"Category"+category+ "]";
	}
	
	
	
}