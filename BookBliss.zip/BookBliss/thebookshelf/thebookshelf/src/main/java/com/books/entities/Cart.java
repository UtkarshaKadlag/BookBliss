package com.books.entities;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="cart")
public class Cart {
	@javax.persistence.Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long cart_ID;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "order_ID", nullable = false)
	private Order order;
	@ManyToOne
	@JoinColumn(name="user_id")
	private User user;
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column
	private LocalDate order_date;
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "address_id")
	@JsonIgnore
	private Address orderAddress;
	@Enumerated(EnumType.STRING)
	@Column(length = 20)
	private Status status;
	@Column
	private String payment;
	@Column(name="total_price")
	private double price;
	
	public Cart() 
	{
		super();
	}
	public Cart(long cart_ID, User user, LocalDate order_date, Address orderAddress, Status status, String payment,double price) 
	{
		super();
		this.cart_ID=cart_ID;
		this.user = user;
		this.order_date = order_date;
		this.orderAddress = orderAddress;
		this.status = status;
		this.payment = payment;
		this.price=price;
	}
	
	
	public long getCart_ID() {
		return cart_ID;
	}
	public void setCart_ID(long cart_ID) {
		this.cart_ID = cart_ID;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public LocalDate getOrder_date() {
		return order_date;
	}
	public void setOrder_date(LocalDate order_date) {
		this.order_date = order_date;
	}
	public Address getOrderAddress() {
		return orderAddress;
	}
	public void setOrderAddress(Address orderAddress) {
		this.orderAddress = orderAddress;
	}
	public Status getStatus() {
		return status;
	}
	public void setStatus(Status status) {
		this.status = status;
	}
	public String getPayment() {
		return payment;
	}
	public void setPayment(String payment) {
		this.payment = payment;
	}
	
	
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	@Override
	public String toString() {
		return "Cart [cart_ID=" + cart_ID + ", order=" + order + ", user=" + user + ", order_date=" + order_date
				+ ", orderAddress=" + orderAddress + ", status=" + status + ", payment=" + payment + ", price=" + price
				+ "]";
	}
	
	
		
	
}
