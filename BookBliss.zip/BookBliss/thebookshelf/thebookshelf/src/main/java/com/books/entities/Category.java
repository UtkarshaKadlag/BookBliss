package com.books.entities;

public enum Category 
{
	ROMANCE,MOTIVATION,BIOGRAPHY,FANTASY,EDUCATIONAL,OTHER
}
