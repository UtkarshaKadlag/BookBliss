package com.books.entities;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.util.List;

@Entity
@Table(name = "orders")
public class Order {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long order_ID;

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "order_ID")
    private List<Cart> cart;

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "order_ID") 
    private List<Book> books;
    
    @Column(name = "quantity")
    private int quantity;

   

    public Order() {
        super();
    }

    public Order(long order_ID, List<Cart> cart, List<Book> books, int quantity) {
        this.order_ID = order_ID;
        this.cart = cart;
        this.books = books;
        this.quantity=quantity;
        
    }

    

    public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public long getOrder_ID() {
        return order_ID;
    }

    public void setOrder_ID(long order_ID) {
        this.order_ID = order_ID;
    }

    public List<Cart> getCart() {
        return cart;
    }

    public void setCart(List<Cart> cart) {
        this.cart = cart;
    }

    public List<Book> getBooks() {
        return books;
    }

    public void setBooks(List<Book> books) {
        this.books = books;
    }

	@Override
	public String toString() {
		return "Order [order_ID=" + order_ID + ", cart=" + cart + ", books=" + books + ", quantity=" + quantity + "]";
	}

   

   
}
