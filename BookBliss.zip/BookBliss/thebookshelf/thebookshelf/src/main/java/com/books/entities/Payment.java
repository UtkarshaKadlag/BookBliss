package com.books.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="payment")
public class Payment{
	
	
	@Column
	private int orderid;
	
	@Column
	private int userid;
	@Id
	@Column
	private long transaction_number  ;
	
	@Column
	
	private String paymentmode;
	
	
	
	public Payment(int orderid, int userid, String paymentmode) {
		super();
		
		this.orderid = orderid;
		this.userid = userid;
		this.paymentmode = paymentmode;
	}

	public void setTransaction_number(long transaction_number) {
		this.transaction_number = transaction_number;
	}

	public Payment() {
		super();
		
	}

	public long getTransaction_number() {
		return transaction_number;
	}

	public int getOrderid() {
		return orderid;
	}

	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}

	public int getUserrid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public String getPaymentmode() {
		return paymentmode;
	}

	public void setPaymentmode(String paymentmode) {
		this.paymentmode = paymentmode;
	}

	@Override
	public String toString() {
		return "Payment [orderid=" + orderid + ", userid=" + userid
				+ ", paymentmode=" + paymentmode + "]";
	}
	
	
	
}
