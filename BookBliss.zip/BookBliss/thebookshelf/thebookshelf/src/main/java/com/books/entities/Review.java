package com.books.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.data.annotation.Id;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="review")
public class Review 
{

		@javax.persistence.Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private Long reviewID;
		
		@ManyToOne(fetch = FetchType.LAZY)
		@JoinColumn(name="user_id", nullable=false)
		private User user;
		
		@OneToOne(fetch = FetchType.LAZY)
		@JoinColumn(name = "book_id", nullable=false)
		private Book book;
		@NotNull
		@Size(min = 1, max = 500)
		@Column(name = "description", nullable=false)
		private String description;
		@Min(1)
		@Max(5)
		@Column(name="rating", nullable = false)
		private int rating;
		
		public Review() {
			super();}
		

		public Review(Long reviewID, User user, Book book, String description, int rating) {
			super();
			this.reviewID = reviewID;
			this.user = user;
			this.book = book;
			this.description = description;
			this.rating = rating;
		}

		public Long getReviewID() {
			return reviewID;
		}

		public void setReviewID(Long reviewID) {
			this.reviewID = reviewID;
		}

		public User getUser() {
			return user;
		}

		

		public void setUser(User user) {
			this.user = user;
		}

		public Book getBook() {
			return book;
		}

		public void setBook(Book book) {
			this.book = book;
		}

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}

		public int getRating() {
			return rating;
		}

		public void setRating(int rating) {
			this.rating = rating;
		}


		@Override
		public String toString() {
			return "Review [reviewID=" + reviewID + ", user=" + user + ", book=" + book + ", description="
					+ description + ", rating=" + rating + "]";
		}
		
}
