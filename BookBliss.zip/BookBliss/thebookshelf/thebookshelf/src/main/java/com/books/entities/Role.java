package com.books.entities;

public enum Role {

	ADMIN,CUSTOMER
}
