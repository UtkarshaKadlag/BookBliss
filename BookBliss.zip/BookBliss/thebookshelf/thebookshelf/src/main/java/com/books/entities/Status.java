package com.books.entities;

public enum Status {

	PENDING,DELIVERED,IN_PROGRESS
}
