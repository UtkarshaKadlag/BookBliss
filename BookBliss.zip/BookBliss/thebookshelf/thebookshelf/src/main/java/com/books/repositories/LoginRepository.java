package com.books.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.books.entities.Login;

@Repository
@Transactional
public interface LoginRepository extends JpaRepository<Login, Integer> {
	
	
	public Optional<Login> findByUsernameAndPassword(String uname,String pwd);

	public Optional<Login> findByUsername(String uname);




}
