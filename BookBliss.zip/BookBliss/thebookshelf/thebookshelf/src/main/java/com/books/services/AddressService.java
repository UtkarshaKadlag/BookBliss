package com.books.services;

import java.util.List;

import com.books.entities.Address;

public interface AddressService {
	Address addAddress(Address address);
	Address deleteAddress(long address_ID);
	Address updateAddress(long address_ID,Address address);
	List<Address> getAllAddress();
}
