package com.books.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.books.entities.Address;
import com.books.entities.Book;
import com.books.repositories.AddressRepository;

@Service
@Transactional
public class AddressServiceImpl implements AddressService{
	
	@Autowired
	private AddressRepository addressRepository;
	
	@Override
	public List<Address> getAllAddress() 
	{
		return addressRepository.findAll();
	}

	@Override
	public Address addAddress(Address address) {
		Address add = addressRepository.save(address);
		return add;
	}

	@Override
	public Address deleteAddress(long address_ID) 
	{
		Optional<Address> optionalAddress= addressRepository.findById(address_ID);
		if(optionalAddress.isPresent())
		{
			addressRepository.deleteById(address_ID);
			return optionalAddress.get();
		}
		else
		{
			throw new RuntimeException("Address not found with id"+address_ID);
		}
	}

	@Override
	public Address updateAddress(long address_ID, Address address) 
	{
			Optional<Address> optionalAddress = addressRepository.findById(address_ID);
			if(optionalAddress.isPresent())
			{
				Address add = optionalAddress.get();
				add.setAdrLine1(address.getAdrLine1());
				add.setAdrLine2(address.getAdrLine2());
				add.setCity(address.getCity());
				add.setState(address.getState());
				add.setZipCode(address.getZipCode());
				add.setCountry(address.getCountry());
				return addressRepository.save(add);
			}
			else
			{
				throw new RuntimeException("Address not found with id"+address_ID);
			}
		
	}

	
	
	

}
