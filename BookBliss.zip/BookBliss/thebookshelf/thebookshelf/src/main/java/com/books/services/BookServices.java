package com.books.services;

import java.util.List;
import java.util.Optional;

import com.books.entities.Book;

public interface BookServices 
{
	Book addBook(Book book);
	List<Book> getAll();
	Book removeBook(Long id);
	Book updateBook(Long id,Book  book);
	List<Book> sortByCategory();
	List<Book> searchByAuthor(String name);

	
	    
}
