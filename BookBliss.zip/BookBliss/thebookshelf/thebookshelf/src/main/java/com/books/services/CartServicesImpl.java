package com.books.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.books.entities.Cart;
import com.books.repositories.CartRepository;

@Service
@Transactional
public class CartServicesImpl implements CartServices {
	
	@Autowired
	private CartRepository orderRepository;

	@Override
	public List<Cart> displayAllOrders()
	{
		return orderRepository.findAll();
	}
	
	@Override
	public Cart addOrder(Cart order)
	{
		Cart orders = orderRepository.save(order);
		return orders;
	}
	
	@Override
	public Cart updateOrder(Long cart_ID, Cart cartDetails)
	{
		Optional<Cart> optionalOrder = orderRepository.findById(cart_ID);
		if(optionalOrder.isPresent())
		{
			Cart cart = optionalOrder.get();
			cart.setCart_ID(cartDetails.getCart_ID());
			cart.setOrder_date(cartDetails.getOrder_date());
			cart.setOrderAddress(cartDetails.getOrderAddress());
			cart.setStatus(cartDetails.getStatus());
			cart.setPayment(cartDetails.getPayment());
			cart.setUser(cartDetails.getUser());
			return orderRepository.save(cart);
		}
		else
		{
			throw new RuntimeException("Book not found with id"+cart_ID);
		}
	}
	
	public Cart deleteOrder(Long cart_ID)
	{
		Optional<Cart> orders = orderRepository.findById(cart_ID);
		if(orders.isPresent())
		{
			orderRepository.deleteById(cart_ID);
			return orders.get();
		}
		else
		{
			throw new RuntimeException("Order not found with id"+cart_ID);
		}
	}
	
	
}
