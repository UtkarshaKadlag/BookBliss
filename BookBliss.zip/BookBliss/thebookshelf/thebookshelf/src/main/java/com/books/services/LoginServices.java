//package com.books.services;
//
//import java.util.Base64;
//import java.util.Optional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.books.entities.Login;
//import com.books.entities.User;
//import com.books.exception.DuplicateEntryException;
//import com.books.exception.NotFoundException;
//import com.books.repositories.LoginRepository;
//import com.books.repositories.UserRepository;
//import com.books.utils.Constants;
//
//@Service
//public class LoginServices{
//	@Autowired
//	LoginRepository lrepo;
//	
//	@Autowired
//	UserRepository userrepo;
//	
//	
//	
//	public Login add(Login l) throws DuplicateEntryException {
//		if(lrepo.findByUsername(l.getUsername()).isPresent()){
//            throw new DuplicateEntryException(String.format("Username=%s already exists.", l.getUsername()));
//        }
//		String encodePassword = Base64.getEncoder().encodeToString(l.getPassword().getBytes());
//		l.setPassword(encodePassword);
//		return lrepo.save(l); //save object in database
//	}
//	
//	
//	
//	public Object checkLogin(String uname, String pwd) throws NotFoundException
//	{  
////		String encodePassword = Base64.getEncoder().encodeToString(pwd.getBytes());
//		String encodePassword = pwd;
//		Optional<Login> l = lrepo.findByUsernameAndPassword(uname, encodePassword);
//		if(l.get().isDeleted()== false) 
//		{
//        	if (l.isPresent() && l.get().getRole().equals("buyer")) 
//        	{
//            Login loginObject = l.get();
//            Optional<Login> ob = userrepo.findByUserid(loginObject);
//            if (ob.isPresent()) 
//            {
//            	//ob.get().getUserid().setPassword(null);
//                return ob.get();
//            } 
//            else 
//            {
//            	throw new NotFoundException(Constants.INVALID_CREDENTIALS_ERROR);
//            }
//        }
//        else if(l.isPresent() && l.get().getRole().equals("admin"))
//        {
//        	 //l.get().setPassword(null);
//        	 return l.get();
//        }
//        else
//        	throw new NotFoundException(Constants.INVALID_CREDENTIALS_ERROR);
//        }
//		else {
//			throw new NotFoundException(Constants.INVALID_CREDENTIALS_ERROR);
//		}
//        
//    }
//	
//	
//}
//
