package com.books.services;

import java.util.List;

import com.books.entities.Order;

public interface OrderServices 
{
	Order addOrderDetails(Order orderDetails);
	List<Order> getOrderDetails();
	Order updateOrderD(Long id, Order orderdetail);
}
