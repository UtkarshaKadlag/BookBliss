package com.books.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.books.entities.Order;
import com.books.repositories.OrderRepository;

@Service
@Transactional
public class OrderServicesImpl implements OrderServices 
{
	@Autowired
	private OrderRepository orderRepository;
	
	
	
	@Override
	public List<Order> getOrderDetails()
	{
		List<Order> orderd = orderRepository.findAll();
		return orderd;
	}
	
	@Override
	public Order updateOrderD(Long order_ID, Order orderdetails)
	{
		Optional<Order> optionalOrder = orderRepository.findById(order_ID);
		if(optionalOrder.isPresent())
		{
			Order orderdetail = optionalOrder.get();
			orderdetail.setBooks(orderdetails.getBooks());
			orderdetail.setCart(orderdetails.getCart());;
			orderdetail.setQuantity(orderdetails.getQuantity());
			
			
			return orderRepository.save(orderdetail);
		}
		else
		{
			throw new RuntimeException("Book not found with id"+order_ID);
		}
	}

	@Override
	public Order addOrderDetails(Order orderDetails) {
		return orderRepository.save(orderDetails);
	}
}
