package com.books.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.books.entities.Payment;
import com.books.repositories.PaymentRepository;

@Service
@Transactional
public class PaymentServiceImpl implements PaymentServices 
{
	@Autowired
	private PaymentRepository paymentRepository;
	
	@Override
	public Payment addPayment(Payment payment) {
		Payment pay = paymentRepository.save(payment);
		return pay;
	}

}
