package com.books.services;

import com.books.entities.Payment;

public interface PaymentServices {
	
	Payment addPayment(Payment payment);

}
