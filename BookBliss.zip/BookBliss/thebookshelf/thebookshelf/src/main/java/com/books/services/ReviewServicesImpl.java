package com.books.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.books.entities.Review;
import com.books.exception.ReviewNotFoundException;
import com.books.repositories.ReviewRepository;

@Service
@Transactional
public class ReviewServicesImpl implements ReviewServices {

    @Autowired
    private ReviewRepository reviewRepository;

    @Override
    public List<Review> getAllReviews() {
        return reviewRepository.findAll();
    }

    @Override
    public Review addReview(Review review) {
        // Ensure that review data is valid before saving
        if (review == null) {
            throw new IllegalArgumentException("Review cannot be null");
        }
        return reviewRepository.save(review);
    }

    @Override
    public Review deleteReview(Long id) {
        Optional<Review> optionalReview = reviewRepository.findById(id);
        if (optionalReview.isPresent()) {
            reviewRepository.deleteById(id);
            return optionalReview.get();
        } else {
            throw new ReviewNotFoundException("Review with ID " + id + " not found");
        }
    }
}
