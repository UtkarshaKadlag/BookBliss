package com.books.utils;

public class Constants 
{
	public static final String INVALID_CREDENTIALS_ERROR="Invalid Credentials";
	public static final String BOOK_NOT_FOUND="Book not found";

}
