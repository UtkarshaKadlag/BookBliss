package com.books.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="author")
public class Author extends BaseEntity {
		@Column(name="aname",length=20)
		private String aname;
		@Column(name="description",length=100)
		private String description;
		
		
		public Author() {
			super();
		}
		public Author(String aname, String description) {
			super();
			this.aname = aname;
			this.description = description;
		}
		public String getAname() {
			return aname;
		}
		public void setAname(String aname) {
			this.aname = aname;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		@Override
		public String toString() {
			return "Author [aname=" + aname + ", description=" + description + "]";
		}
		
		
}
