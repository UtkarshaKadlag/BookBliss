package com.books.entities;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="books")
public class Book extends BaseEntity{
	@Column(length = 20, name = "book_name")
	private String bookName;
	@Column(length = 20, name = "price")
	private float price;
	@Column(length = 20, name = "quantity")
	private int quantity;
	@Column(length = 20, name = "description")
	private String description;
	@ManyToOne(cascade =CascadeType.ALL,fetch = FetchType.EAGER)
	@JoinColumn(name = "author_id")
	private Author author;
	
	public Book() 
	{
		super();
	}
	
	public Book(String bookName, float price, int quantity, String description, Author author) 
	{
		super();
		this.bookName = bookName;
		this.price = price;
		this.quantity = quantity;
		this.description = description;
		this.author = author;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Author getAuthor() {
		return author;
	}
	public void setAuthor(Author author) {
		this.author = author;
	}
	@Override
	public String toString() {
		return "Book [bookName=" + bookName + ", price=" + price + ", quantity=" + quantity + ", description="
				+ description + ", author=" + author + "]";
	}
	
	
}