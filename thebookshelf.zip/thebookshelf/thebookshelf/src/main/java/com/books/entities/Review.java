package com.books.entities;

import java.time.LocalDate;

import javax.annotation.Generated;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.data.annotation.Id;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="Review")
public class Review extends BaseEntity
{
	
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private Long reviewID;
		
		@ManyToOne(fetch = FetchType.LAZY)
		@JoinColumn(name="user_id", nullable=false)
		@JsonIgnore
		private User user;
		
		@OneToOne(fetch = FetchType.EAGER)
		@JoinColumn(name = "bookID", nullable=false)
		@JsonIgnore
		private Book bookID;
	
		@Column(name = "description", nullable=false)
		private String description;
		
		@Column(name="rating")
		private int rating;

		public Long getReviewID() {
			return reviewID;
		}

		public void setReviewID(Long reviewID) {
			this.reviewID = reviewID;
		}

		public User getUser() {
			return user;
		}

		public void setUser(User user) {
			this.user = user;
		}

		public Book getBookID() {
			return bookID;
		}

		public void setBookID(Book bookID) {
			this.bookID = bookID;
		}

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}

		public int getRating() {
			return rating;
		}

		public void setRating(int rating) {
			this.rating = rating;
		}
		
		
}
