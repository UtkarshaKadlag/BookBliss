package com.books.services;

import com.books.entities.Book;

import java.util.List;

public interface BookServices 
{
	Book addBook(Book book);
	List<Book> getAll();
	Book removeBook(Long id);
	Book updateBook(Long id,Book  book);
//	List<Book> SortBook();
}
