package com.books.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.books.entities.Book;
import com.books.repositories.BookRepository;

@Service
@Transactional
public class BookServicesImpl implements BookServices{

	@Autowired
	private BookRepository bookRepository;
	
	@Override
	public List<Book> getAll()
	{
		return bookRepository.findAll();
	}
	
	@Override
	public Book addBook(Book book)
	{
		 Book books = bookRepository.save(book);
		 return books;
	}
	
	@Override
	public Book updateBook(Long id, Book bookDetails)
	{
		Optional<Book> optionalBook = bookRepository.findById(id);
		if(optionalBook.isPresent())
		{
			Book book = optionalBook.get();
			book.setBookName(bookDetails.getBookName());
			book.setAuthor(bookDetails.getAuthor());
			book.setDescription(book.getDescription());
			book.setPrice(bookDetails.getPrice());
			return bookRepository.save(book);
		}
		else
		{
			throw new RuntimeException("Book not found with id"+id);
		}
	}
	
	@Override
	public Book removeBook(Long id)
	{
		Optional<Book> optionalBook= bookRepository.findById(id);
		if(optionalBook.isPresent())
		{
			bookRepository.deleteById(id);
			return optionalBook.get();
		}
		else
		{
			throw new RuntimeException("Book not found with id"+id);
		}
		
	}

	
}
