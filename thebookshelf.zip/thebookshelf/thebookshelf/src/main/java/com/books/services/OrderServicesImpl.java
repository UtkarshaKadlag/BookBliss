package com.books.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.books.entities.Book;
import com.books.entities.Order;
import com.books.repositories.OrderRepository;

public class OrderServicesImpl implements OrderServices 
{
	@Autowired
	private OrderRepository orderRepository;
	
	
	
	@Override
	public List<Order> getOrderDetails()
	{
		List<Order> orderd = orderRepository.findAll();
		return orderd;
	}
	
	@Override
	public Order updateOrderD(Long id, Order orderdetail)
	{
		Optional<Order> optionalD = orderRepository.findById(id);
		if(optionalD.isPresent())
		{
			Order orderdetails = optionalD.get();
			orderdetail.setId(orderdetail.getId());
			orderdetail.setFirstName(orderdetail.getFirstName());
			orderdetail.setLastName(orderdetail.getLastName());
			orderdetail.setEmailId(orderdetail.getEmailId());
			orderdetail.setPassword(orderdetail.getPassword());
			orderdetail.setMobileNo(orderdetail.getMobileNo());
			orderdetail.setMyAddress(orderdetail.getMyAddress());
			orderdetail.setRole(orderdetail.getRole());
			return orderRepository.save(orderdetail);
		}
		else
		{
			throw new RuntimeException("Book not found with id"+id);
		}
	}

	@Override
	public Order addOrderDetails(Order orderDetails) {
		return orderRepository.save(orderDetails);
	}
}
